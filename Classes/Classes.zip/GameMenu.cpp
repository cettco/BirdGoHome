#include "GameMenu.h"
#include "HelloWorldScene.h"
#include "Levels.h"
#include "About.h"
#define PTM_RATIO 32.0
#define playPressed 1
#define aboutPressed 2
#define exitPressed 3
void GameMenu::pressed(cocos2d::CCObject* pSender)
{
	CCMenuItemImage *menu = (CCMenuItemImage*)pSender;
	if(menu->getTag()==playPressed)
	{
		CCScene *pscene = Levels::scene();
		CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(1,pscene,false));
	}
	if(menu->getTag()==aboutPressed)
	{
		CCScene *pscene = About::scene();
		CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(1,pscene,false));
	}
	if(menu->getTag()==exitPressed)
	{
		CCDirector::sharedDirector()->end();
	}
	//this->i++;
}
CCScene* GameMenu::scene()
{
	//����ת��
	CCScene *scene = CCScene::create();
	CCNodeLoaderLibrary *lib = CCNodeLoaderLibrary::newDefaultCCNodeLoaderLibrary();
	lib->registerCCNodeLoader("Main", MainLayerLoader::loader());
	CCBReader *reader = new CCBReader(lib);
	CCNode *node = reader->readNodeGraphFromFile("Main1.ccbi", scene);
	reader->release(); //ע���ֶ��ͷ��ڴ�
	//CCLabelTTF* pLabel = CCLabelTTF::create("Hello World", "Arial", 24);
	//pLabel->setString
	if (node!=NULL)
	{
		scene->addChild(node,-2); //��node ���ӵ�scene��
		/*CCBAnimationManager* animationManager = (CCBAnimationManager*)node->getUserObject();
		animationManager->runAnimationsForSequenceNamed("Info");*/
	}
	return scene;
}
bool GameMenu::init()
{
	bool bRet = false;
	do 
	{
		//////////////////////////////////////////////////////////////////////////
		// super init first
		//////////////////////////////////////////////////////////////////////////

		CC_BREAK_IF(! CCLayer::init());
		setTouchEnabled(true);

		CCSize winSize = CCDirector::sharedDirector()->getWinSize();
		CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("back.mp3",true);
		bRet = true;
	} while (0);

	return bRet;
}
SEL_MenuHandler GameMenu::onResolveCCBCCMenuItemSelector(CCObject * pTarget,const char * pSelectorName){

	//Bind Menu Events����һ��menu�����������press������ͬ��
	CCB_SELECTORRESOLVER_CCMENUITEM_GLUE(this, "pressed",GameMenu::pressed);
	//CCB_SELECTORRESOLVER_CCMENUITEM_GLUE\

	return NULL;

}

extension::SEL_CCControlHandler GameMenu::onResolveCCBCCControlSelector(CCObject * pTarget, const char * pSelectorName){

	//CCB_SELECTORRESOLVER_CCCONTROL_GLUE(this,"buttonPressed",GameMenu::buttonPressed);
	//CCB_SELECTORRESOLVER_CCCONTROL_GLUE(this,"buttonPressed",GameMenu::buttonPressed);

	return NULL;

}
bool GameMenu::onAssignCCBMemberVariable(cocos2d::CCObject *pTarget, const char *pMemberVariableName, cocos2d::CCNode *pNode)
{
	//CCB_MEMBERVARIABLEASSIGNER_GLUE(this,"sprite1",CCSprite*,this->msprite);
	//CCB_MEMBERVARIABLEASSIGNER_GLUE(this,"mlabel",CCLabelTTF*,this->label);
	//CCB_MEMBERVARIABLEASSIGNER_GLUE(this,"msprite",CCSprite*,this->my);
	return true;
}

